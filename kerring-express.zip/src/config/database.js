const { Sequelize } = require("sequelize");

const dbConnection = new Sequelize("kerring", "root", "sunflower", {
  host: "localhost",
  port: 3306,
  dialect: "mysql",

  pool: {
    max: 5,
    min: 0,
    idle: 10000,
  },
});

module.exports = dbConnection;
