const admin = require("firebase-admin");
const serviceAccount = require("./serviceAccountKey.json");
const fire = admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL:
    "https://kerring-auth-default-rtdb.asia-southeast1.firebasedatabase.app",
});

module.exports = fire;
